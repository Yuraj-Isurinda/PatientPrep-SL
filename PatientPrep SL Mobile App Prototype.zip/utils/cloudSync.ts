import { projectId, publicAnonKey } from './supabase/info';

interface SyncData {
  appointments: any[];
  symptoms: any[];
  medications: any[];
  questions: any[];
  consultationNotes: any[];
}

export const cloudSyncService = {
  async syncData(userData: SyncData, accessToken: string, enableCloudSync: boolean = false) {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-26c2a481/data/sync`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({
          patientData: userData,
          enableCloudSync
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to sync data');
      }

      return { success: true, data };
    } catch (error: any) {
      console.error('Cloud sync error:', error);
      return { success: false, error: error.message };
    }
  },

  async retrieveData(accessToken: string) {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-26c2a481/data/retrieve`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${accessToken}`
        }
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to retrieve data');
      }

      return { success: true, data: data.data, hasCloudData: data.has_cloud_data, lastSync: data.last_sync };
    } catch (error: any) {
      console.error('Data retrieval error:', error);
      return { success: false, error: error.message };
    }
  }
};