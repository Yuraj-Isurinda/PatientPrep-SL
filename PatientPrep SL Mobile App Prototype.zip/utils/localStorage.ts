// Simple local storage utilities for PatientPrep SL
export const storageKeys = {
  PATIENT_DATA: 'patientPrepData',
  USER_PREFERENCES: 'patientPrepPreferences'
};

export const saveData = (key: string, data: any) => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
    return true;
  } catch (error) {
    console.error('Failed to save data to localStorage:', error);
    return false;
  }
};

export const loadData = (key: string, defaultValue: any = null) => {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : defaultValue;
  } catch (error) {
    console.error('Failed to load data from localStorage:', error);
    return defaultValue;
  }
};

export const removeData = (key: string) => {
  try {
    localStorage.removeItem(key);
    return true;
  } catch (error) {
    console.error('Failed to remove data from localStorage:', error);
    return false;
  }
};

export const exportAllData = () => {
  const patientData = loadData(storageKeys.PATIENT_DATA, {});
  const preferences = loadData(storageKeys.USER_PREFERENCES, {});
  
  return {
    patientData,
    preferences,
    exportDate: new Date().toISOString(),
    appVersion: 'PatientPrep SL v1.0'
  };
};