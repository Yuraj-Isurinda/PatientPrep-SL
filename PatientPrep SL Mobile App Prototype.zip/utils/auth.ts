import { supabase } from './supabase/client';
import { projectId, publicAnonKey } from './supabase/info';

export interface User {
  id: string;
  email: string;
  name?: string;
}

export interface AuthState {
  user: User | null;
  loading: boolean;
}

export const authService = {
  async signUp(email: string, password: string, name: string) {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-26c2a481/auth/signup`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({ email, password, name })
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to create account');
      }

      return { user: data.user, error: null };
    } catch (error: any) {
      console.error('Signup error:', error);
      return { user: null, error: error.message };
    }
  },

  async signIn(email: string, password: string) {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        throw error;
      }

      return { 
        user: {
          id: data.user.id,
          email: data.user.email!,
          name: data.user.user_metadata?.name
        }, 
        session: data.session,
        error: null 
      };
    } catch (error: any) {
      console.error('Sign in error:', error);
      return { user: null, session: null, error: error.message };
    }
  },

  async signOut() {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      return { error: null };
    } catch (error: any) {
      console.error('Sign out error:', error);
      return { error: error.message };
    }
  },

  async getCurrentSession() {
    try {
      const { data: { session }, error } = await supabase.auth.getSession();
      if (error) throw error;
      
      if (session?.user) {
        return {
          user: {
            id: session.user.id,
            email: session.user.email!,
            name: session.user.user_metadata?.name
          },
          session,
          error: null
        };
      }
      
      return { user: null, session: null, error: null };
    } catch (error: any) {
      console.error('Get session error:', error);
      return { user: null, session: null, error: error.message };
    }
  }
};