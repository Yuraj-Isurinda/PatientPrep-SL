import React, { useState, useEffect } from 'react';
import { Home } from './components/Home';
import { AppointmentPlanner } from './components/AppointmentPlanner';
import { SymptomLogger } from './components/SymptomLogger';
import { MedicationManager } from './components/MedicationManager';
import { QuestionBuilder } from './components/QuestionBuilder';
import { ConsultationSummary } from './components/ConsultationSummary';
import { PostConsultationNotes } from './components/PostConsultationNotes';
import { SimpleSettings } from './components/SimpleSettings';
import { NavigationBar } from './components/NavigationBar';
import { Toaster } from './components/ui/sonner';
import { Calendar, FileText, Pill, MessageCircleQuestion, ClipboardList, NotebookPen, Settings as SettingsIcon } from 'lucide-react';

export default function App() {
  const [currentView, setCurrentView] = useState('home');
  const [userData, setUserData] = useState({
    appointments: [],
    symptoms: [],
    medications: [],
    questions: [],
    consultationNotes: []
  });

  // Load data from localStorage on app start
  useEffect(() => {
    const savedData = localStorage.getItem('patientPrepData');
    if (savedData) {
      try {
        setUserData(JSON.parse(savedData));
      } catch (error) {
        console.error('Failed to load saved data:', error);
        // Reset to default if corrupted
        localStorage.removeItem('patientPrepData');
      }
    }
  }, []);

  // Save data to localStorage whenever userData changes
  useEffect(() => {
    localStorage.setItem('patientPrepData', JSON.stringify(userData));
  }, [userData]);

  const navigationItems = [
    { id: 'home', label: 'Home', icon: Calendar },
    { id: 'appointments', label: 'Appointments', icon: Calendar },
    { id: 'symptoms', label: 'Symptoms', icon: FileText },
    { id: 'medications', label: 'Medications', icon: Pill },
    { id: 'questions', label: 'Questions', icon: MessageCircleQuestion },
    { id: 'summary', label: 'Summary', icon: ClipboardList },
    { id: 'notes', label: 'Notes', icon: NotebookPen },
    { id: 'settings', label: 'Settings', icon: SettingsIcon }
  ];

  const renderCurrentView = () => {
    switch (currentView) {
      case 'home':
        return <Home userData={userData} setCurrentView={setCurrentView} />;
      case 'appointments':
        return <AppointmentPlanner userData={userData} setUserData={setUserData} />;
      case 'symptoms':
        return <SymptomLogger userData={userData} setUserData={setUserData} />;
      case 'medications':
        return <MedicationManager userData={userData} setUserData={setUserData} />;
      case 'questions':
        return <QuestionBuilder userData={userData} setUserData={setUserData} />;
      case 'summary':
        return <ConsultationSummary userData={userData} />;
      case 'notes':
        return <PostConsultationNotes userData={userData} setUserData={setUserData} />;
      case 'settings':
        return <SimpleSettings userData={userData} setUserData={setUserData} setCurrentView={setCurrentView} />;
      default:
        return <Home userData={userData} setCurrentView={setCurrentView} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile App Container */}
      <div className="max-w-md mx-auto bg-background min-h-screen flex flex-col">
        {/* Header */}
        <header className="bg-primary text-primary-foreground p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-medium">PatientPrep SL</h1>
              <p className="text-sm opacity-90">Your Smart Consultation Companion</p>
            </div>
            <div className="w-8 h-8 bg-primary-foreground/20 rounded-full flex items-center justify-center">
              <span className="text-xs">PS</span>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto">
          {renderCurrentView()}
        </main>

        {/* Bottom Navigation */}
        <NavigationBar 
          items={navigationItems}
          currentView={currentView}
          setCurrentView={setCurrentView}
        />

        {/* Privacy Notice */}
        <div className="px-4 py-2 bg-muted/50 border-t">
          <p className="text-xs text-muted-foreground text-center">
            🔒 Your data stays private on your device only
          </p>
        </div>
      </div>

      {/* Toast notifications */}
      <Toaster position="top-center" />
    </div>
  );
}