import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { FileText, Plus, Trash2, AlertCircle, Lightbulb } from 'lucide-react';

interface SymptomLoggerProps {
  userData: any;
  setUserData: (data: any) => void;
}

export function SymptomLogger({ userData, setUserData }: SymptomLoggerProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    symptom: '',
    description: '',
    onset: '',
    duration: '',
    severity: '',
    triggers: '',
    relief: '',
    frequency: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleAddSymptom = () => {
    if (formData.symptom) {
      const newSymptom = {
        ...formData,
        id: Date.now().toString(),
        dateLogged: new Date().toISOString()
      };
      
      setUserData({
        ...userData,
        symptoms: [...userData.symptoms, newSymptom]
      });
      
      setFormData({
        symptom: '',
        description: '',
        onset: '',
        duration: '',
        severity: '',
        triggers: '',
        relief: '',
        frequency: ''
      });
      
      setIsDialogOpen(false);
    }
  };

  const handleDeleteSymptom = (symptomId: string) => {
    setUserData({
      ...userData,
      symptoms: userData.symptoms.filter((sym: any) => sym.id !== symptomId)
    });
  };

  const getAIPrompts = (symptom: string) => {
    const prompts = {
      'headache': [
        'Consider noting if the headache is worse at certain times of day',
        'Does bright light or noise make it worse?',
        'Have you tried any pain relievers? Did they help?'
      ],
      'fatigue': [
        'How many hours of sleep are you getting?',
        'Does rest help, or do you feel tired even after sleeping?',
        'Are you taking any new medications?'
      ],
      'pain': [
        'Rate your pain on a scale of 1-10',
        'Is the pain sharp, dull, throbbing, or burning?',
        'Does movement make it better or worse?'
      ],
      'default': [
        'When did this symptom first appear?',
        'Does anything make it better or worse?',
        'How often does this happen?'
      ]
    };

    const key = symptom.toLowerCase();
    return prompts[key] || prompts.default;
  };

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2>Symptom Log</h2>
          <p className="text-muted-foreground">Track your symptoms for consultation</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Log
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Log New Symptom</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="symptom">Symptom*</Label>
                <Input
                  id="symptom"
                  placeholder="e.g., Headache, Fatigue, Chest pain"
                  value={formData.symptom}
                  onChange={(e) => handleInputChange('symptom', e.target.value)}
                />
              </div>
              
              {formData.symptom && (
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="flex items-start gap-2">
                    <Lightbulb className="w-4 h-4 text-blue-600 mt-0.5" />
                    <div>
                      <p className="text-sm text-blue-800 font-medium mb-2">AI Suggestions:</p>
                      <ul className="text-sm text-blue-700 space-y-1">
                        {getAIPrompts(formData.symptom).map((prompt, index) => (
                          <li key={index}>• {prompt}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe the symptom in detail..."
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="onset">When did it start?</Label>
                  <Input
                    id="onset"
                    placeholder="e.g., 3 days ago"
                    value={formData.onset}
                    onChange={(e) => handleInputChange('onset', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="severity">Severity</Label>
                  <Select value={formData.severity} onValueChange={(value) => handleInputChange('severity', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mild">Mild (1-3)</SelectItem>
                      <SelectItem value="moderate">Moderate (4-6)</SelectItem>
                      <SelectItem value="severe">Severe (7-10)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="triggers">What makes it worse?</Label>
                <Input
                  id="triggers"
                  placeholder="e.g., Movement, stress, food"
                  value={formData.triggers}
                  onChange={(e) => handleInputChange('triggers', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="relief">What makes it better?</Label>
                <Input
                  id="relief"
                  placeholder="e.g., Rest, medication, heat"
                  value={formData.relief}
                  onChange={(e) => handleInputChange('relief', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="frequency">How often?</Label>
                <Select value={formData.frequency} onValueChange={(value) => handleInputChange('frequency', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select frequency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="constant">Constant</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="few-times-week">Few times a week</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="rarely">Rarely</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button onClick={handleAddSymptom} className="w-full">
                Add Symptom
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Symptoms List */}
      {userData.symptoms.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <FileText className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="mb-2">No symptoms logged</h3>
            <p className="text-muted-foreground mb-4">Start tracking your symptoms to help your doctor understand your condition better.</p>
            <Button onClick={() => setIsDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Log First Symptom
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {userData.symptoms.map((symptom: any) => (
            <Card key={symptom.id}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <CardTitle className="text-base flex items-center gap-2">
                    <FileText className="w-4 h-4" />
                    {symptom.symptom}
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    {symptom.severity && (
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        symptom.severity === 'severe' 
                          ? 'bg-red-100 text-red-800' 
                          : symptom.severity === 'moderate'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-green-100 text-green-800'
                      }`}>
                        {symptom.severity}
                      </span>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteSymptom(symptom.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground">
                  Logged {new Date(symptom.dateLogged).toLocaleDateString()}
                </p>
              </CardHeader>
              <CardContent className="pt-0 space-y-3">
                {symptom.description && (
                  <p className="text-sm">{symptom.description}</p>
                )}
                <div className="grid grid-cols-1 gap-2 text-sm">
                  {symptom.onset && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Started:</span>
                      <span>{symptom.onset}</span>
                    </div>
                  )}
                  {symptom.frequency && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Frequency:</span>
                      <span className="capitalize">{symptom.frequency.replace('-', ' ')}</span>
                    </div>
                  )}
                  {symptom.triggers && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Triggers:</span>
                      <span>{symptom.triggers}</span>
                    </div>
                  )}
                  {symptom.relief && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Relief:</span>
                      <span>{symptom.relief}</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* AI Tip */}
      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <h4 className="text-sm font-medium text-blue-900">Preparation Tip</h4>
              <p className="text-sm text-blue-800 mt-1">
                The more detailed your symptom log, the better your doctor can understand your condition. Don't forget to mention how symptoms affect your daily activities.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}