import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { NotebookPen, Plus, Trash2, Calendar, User, AlertCircle } from 'lucide-react';

interface PostConsultationNotesProps {
  userData: any;
  setUserData: (data: any) => void;
}

export function PostConsultationNotes({ userData, setUserData }: PostConsultationNotesProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    consultationDate: '',
    doctorName: '',
    diagnosis: '',
    treatmentPlan: '',
    prescriptions: '',
    followUpInstructions: '',
    nextAppointment: '',
    additionalNotes: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleAddNote = () => {
    if (formData.consultationDate && formData.doctorName) {
      const newNote = {
        ...formData,
        id: Date.now().toString(),
        dateCreated: new Date().toISOString()
      };
      
      setUserData({
        ...userData,
        consultationNotes: [...userData.consultationNotes, newNote]
      });
      
      setFormData({
        consultationDate: '',
        doctorName: '',
        diagnosis: '',
        treatmentPlan: '',
        prescriptions: '',
        followUpInstructions: '',
        nextAppointment: '',
        additionalNotes: ''
      });
      
      setIsDialogOpen(false);
    }
  };

  const handleDeleteNote = (noteId: string) => {
    setUserData({
      ...userData,
      consultationNotes: userData.consultationNotes.filter((note: any) => note.id !== noteId)
    });
  };

  const sortedNotes = [...userData.consultationNotes].sort((a, b) => 
    new Date(b.consultationDate).getTime() - new Date(a.consultationDate).getTime()
  );

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2>Consultation Notes</h2>
          <p className="text-muted-foreground">Record important details from your visits</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Add
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>New Consultation Notes</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="consultationDate">Date*</Label>
                  <Input
                    id="consultationDate"
                    type="date"
                    value={formData.consultationDate}
                    onChange={(e) => handleInputChange('consultationDate', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="doctorName">Doctor*</Label>
                  <Input
                    id="doctorName"
                    placeholder="Dr. Smith"
                    value={formData.doctorName}
                    onChange={(e) => handleInputChange('doctorName', e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="diagnosis">Diagnosis/Assessment</Label>
                <Textarea
                  id="diagnosis"
                  placeholder="What did the doctor say about your condition?"
                  value={formData.diagnosis}
                  onChange={(e) => handleInputChange('diagnosis', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="treatmentPlan">Treatment Plan</Label>
                <Textarea
                  id="treatmentPlan"
                  placeholder="Recommended treatments, lifestyle changes, etc."
                  value={formData.treatmentPlan}
                  onChange={(e) => handleInputChange('treatmentPlan', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="prescriptions">New Prescriptions</Label>
                <Textarea
                  id="prescriptions"
                  placeholder="Medications prescribed, dosages, instructions..."
                  value={formData.prescriptions}
                  onChange={(e) => handleInputChange('prescriptions', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="followUpInstructions">Follow-up Instructions</Label>
                <Textarea
                  id="followUpInstructions"
                  placeholder="What to watch for, when to return, etc."
                  value={formData.followUpInstructions}
                  onChange={(e) => handleInputChange('followUpInstructions', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="nextAppointment">Next Appointment</Label>
                <Input
                  id="nextAppointment"
                  placeholder="e.g., 2 weeks, as needed"
                  value={formData.nextAppointment}
                  onChange={(e) => handleInputChange('nextAppointment', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="additionalNotes">Additional Notes</Label>
                <Textarea
                  id="additionalNotes"
                  placeholder="Any other important information discussed..."
                  value={formData.additionalNotes}
                  onChange={(e) => handleInputChange('additionalNotes', e.target.value)}
                />
              </div>

              <Button onClick={handleAddNote} className="w-full">
                Save Notes
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Consultation Notes List */}
      {sortedNotes.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <NotebookPen className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="mb-2">No consultation notes yet</h3>
            <p className="text-muted-foreground mb-4">Record important details from your doctor visits to track your healthcare journey.</p>
            <Button onClick={() => setIsDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add First Note
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {sortedNotes.map((note: any) => (
            <Card key={note.id} className="border-l-4 border-l-primary">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-base flex items-center gap-2 mb-2">
                      <Calendar className="w-4 h-4" />
                      {new Date(note.consultationDate).toLocaleDateString('en-GB', {
                        weekday: 'short',
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric'
                      })}
                    </CardTitle>
                    <p className="text-sm text-muted-foreground flex items-center gap-2">
                      <User className="w-4 h-4" />
                      {note.doctorName}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDeleteNote(note.id)}
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="pt-0 space-y-4">
                {note.diagnosis && (
                  <div>
                    <h4 className="text-sm font-medium text-foreground mb-1">Diagnosis/Assessment</h4>
                    <p className="text-sm bg-muted/50 p-3 rounded-lg">{note.diagnosis}</p>
                  </div>
                )}
                
                {note.treatmentPlan && (
                  <div>
                    <h4 className="text-sm font-medium text-foreground mb-1">Treatment Plan</h4>
                    <p className="text-sm bg-blue-50 border border-blue-200 p-3 rounded-lg text-blue-900">{note.treatmentPlan}</p>
                  </div>
                )}

                {note.prescriptions && (
                  <div>
                    <h4 className="text-sm font-medium text-foreground mb-1">New Prescriptions</h4>
                    <p className="text-sm bg-green-50 border border-green-200 p-3 rounded-lg text-green-900">{note.prescriptions}</p>
                  </div>
                )}

                {note.followUpInstructions && (
                  <div>
                    <h4 className="text-sm font-medium text-foreground mb-1">Follow-up Instructions</h4>
                    <p className="text-sm bg-orange-50 border border-orange-200 p-3 rounded-lg text-orange-900">{note.followUpInstructions}</p>
                  </div>
                )}

                {note.nextAppointment && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Next Appointment:</span>
                    <span className="font-medium">{note.nextAppointment}</span>
                  </div>
                )}

                {note.additionalNotes && (
                  <div>
                    <h4 className="text-sm font-medium text-foreground mb-1">Additional Notes</h4>
                    <p className="text-sm text-muted-foreground">{note.additionalNotes}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Tips */}
      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <h4 className="text-sm font-medium text-blue-900">Recording Tips</h4>
              <ul className="text-sm text-blue-800 mt-1 space-y-1">
                <li>• Record notes immediately after your consultation while it's fresh</li>
                <li>• Include specific medication names, dosages, and instructions</li>
                <li>• Note any warning signs your doctor mentioned</li>
                <li>• Keep track of follow-up appointments and deadlines</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}