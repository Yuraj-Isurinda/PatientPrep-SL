import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Calendar, FileText, Pill, MessageCircleQuestion, AlertCircle, Clock } from 'lucide-react';

interface HomeProps {
  userData: any;
  setCurrentView: (view: string) => void;
}

export function Home({ userData, setCurrentView }: HomeProps) {
  const upcomingAppointments = userData.appointments.filter((apt: any) => 
    new Date(apt.date) >= new Date()
  ).slice(0, 2);

  const quickActions = [
    { id: 'symptoms', label: 'Log Symptoms', icon: FileText, color: 'bg-red-50 text-red-600 border-red-200' },
    { id: 'medications', label: 'Add Medication', icon: Pill, color: 'bg-blue-50 text-blue-600 border-blue-200' },
    { id: 'questions', label: 'Prepare Questions', icon: MessageCircleQuestion, color: 'bg-green-50 text-green-600 border-green-200' },
    { id: 'appointments', label: 'Schedule Visit', icon: Calendar, color: 'bg-purple-50 text-purple-600 border-purple-200' }
  ];

  return (
    <div className="p-4 space-y-6">
      {/* Welcome Section */}
      <div className="space-y-2">
        <h2>Good morning!</h2>
        <p className="text-muted-foreground">Let's prepare for your next consultation</p>
      </div>

      {/* Upcoming Appointments */}
      {upcomingAppointments.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Clock className="w-5 h-5" />
              Upcoming Appointments
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {upcomingAppointments.map((appointment: any, index: number) => (
              <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <div>
                  <p className="font-medium">{appointment.doctorName}</p>
                  <p className="text-sm text-muted-foreground">{appointment.specialty}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium">{new Date(appointment.date).toLocaleDateString()}</p>
                  <p className="text-sm text-muted-foreground">{appointment.time}</p>
                </div>
              </div>
            ))}
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full mt-2"
              onClick={() => setCurrentView('summary')}
            >
              View Consultation Summary
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Quick Actions */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <Button
                  key={action.id}
                  variant="outline"
                  className={`h-20 flex-col gap-2 ${action.color}`}
                  onClick={() => setCurrentView(action.id)}
                >
                  <Icon className="w-6 h-6" />
                  <span className="text-sm">{action.label}</span>
                </Button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* AI Assistant Tips */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg">
            <AlertCircle className="w-5 h-5" />
            Consultation Tips
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-sm text-blue-800">
              💡 <strong>Preparation Tip:</strong> Write down when your symptoms started and what makes them better or worse.
            </p>
          </div>
          <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
            <p className="text-sm text-green-800">
              📝 <strong>Don't forget:</strong> Bring a list of all medications, including over-the-counter drugs and supplements.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Data Summary */}
      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-medium text-primary">{userData.symptoms.length}</p>
            <p className="text-sm text-muted-foreground">Symptoms Logged</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-medium text-primary">{userData.medications.length}</p>
            <p className="text-sm text-muted-foreground">Medications Listed</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}