import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Calendar, FileText, Pill, MessageCircleQuestion, User, Clock, AlertCircle } from 'lucide-react';

interface ConsultationSummaryProps {
  userData: any;
}

export function ConsultationSummary({ userData }: ConsultationSummaryProps) {
  const upcomingAppointments = userData.appointments.filter((apt: any) => 
    new Date(apt.date) >= new Date()
  ).slice(0, 2);

  const handlePrint = () => {
    window.print();
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600';
      case 'medium': return 'text-yellow-600';
      case 'low': return 'text-green-600';
      default: return 'text-muted-foreground';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'severe': return 'text-red-600';
      case 'moderate': return 'text-yellow-600';
      case 'mild': return 'text-green-600';
      default: return 'text-muted-foreground';
    }
  };

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2>Consultation Summary</h2>
          <p className="text-muted-foreground">Comprehensive overview for your doctor</p>
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={handlePrint}
          className="print:hidden"
        >
          Print Summary
        </Button>
      </div>

      {/* Summary Overview */}
      <Card className="border-primary/20 bg-primary/5">
        <CardHeader>
          <CardTitle className="text-lg">Summary Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="text-center p-3 bg-background rounded-lg">
              <p className="text-2xl font-medium text-primary">{userData.symptoms.length}</p>
              <p className="text-sm text-muted-foreground">Symptoms</p>
            </div>
            <div className="text-center p-3 bg-background rounded-lg">
              <p className="text-2xl font-medium text-primary">{userData.medications.length}</p>
              <p className="text-sm text-muted-foreground">Medications</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-3 bg-background rounded-lg">
              <p className="text-2xl font-medium text-primary">{userData.questions.length}</p>
              <p className="text-sm text-muted-foreground">Questions</p>
            </div>
            <div className="text-center p-3 bg-background rounded-lg">
              <p className="text-2xl font-medium text-primary">{upcomingAppointments.length}</p>
              <p className="text-sm text-muted-foreground">Upcoming</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Upcoming Appointments */}
      {upcomingAppointments.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Upcoming Appointments
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {upcomingAppointments.map((appointment: any, index: number) => (
              <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <div>
                  <p className="font-medium">{appointment.doctorName}</p>
                  {appointment.specialty && <p className="text-sm text-muted-foreground">{appointment.specialty}</p>}
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium">{new Date(appointment.date).toLocaleDateString()}</p>
                  <p className="text-sm text-muted-foreground">{appointment.time}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Current Symptoms */}
      {userData.symptoms.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Current Symptoms
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {userData.symptoms.slice(0, 5).map((symptom: any, index: number) => (
              <div key={index} className="border-l-4 border-primary/30 pl-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium">{symptom.symptom}</h4>
                  {symptom.severity && (
                    <span className={`text-sm ${getSeverityColor(symptom.severity)} capitalize`}>
                      {symptom.severity}
                    </span>
                  )}
                </div>
                {symptom.description && (
                  <p className="text-sm text-muted-foreground mb-2">{symptom.description}</p>
                )}
                <div className="grid grid-cols-2 gap-4 text-xs text-muted-foreground">
                  {symptom.onset && (
                    <div>
                      <span className="font-medium">Started:</span> {symptom.onset}
                    </div>
                  )}
                  {symptom.frequency && (
                    <div>
                      <span className="font-medium">Frequency:</span> {symptom.frequency.replace('-', ' ')}
                    </div>
                  )}
                  {symptom.triggers && (
                    <div className="col-span-2">
                      <span className="font-medium">Triggers:</span> {symptom.triggers}
                    </div>
                  )}
                  {symptom.relief && (
                    <div className="col-span-2">
                      <span className="font-medium">Relief:</span> {symptom.relief}
                    </div>
                  )}
                </div>
              </div>
            ))}
            {userData.symptoms.length > 5 && (
              <p className="text-sm text-muted-foreground text-center py-2">
                ... and {userData.symptoms.length - 5} more symptoms
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {/* Current Medications */}
      {userData.medications.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Pill className="w-5 h-5" />
              Current Medications
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {userData.medications.map((medication: any, index: number) => (
                <div key={index} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                  <div className="flex-1">
                    <p className="font-medium">{medication.name}</p>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      {medication.dosage && <span>{medication.dosage}</span>}
                      {medication.frequency && <span>• {medication.frequency.replace('-', ' ')}</span>}
                      {medication.purpose && <span>• {medication.purpose}</span>}
                    </div>
                  </div>
                  {medication.prescribedBy && (
                    <div className="text-xs text-muted-foreground text-right">
                      {medication.prescribedBy}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Questions for Doctor */}
      {userData.questions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageCircleQuestion className="w-5 h-5" />
              Questions for Doctor
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {userData.questions
                .sort((a: any, b: any) => {
                  const priorityOrder = { high: 3, medium: 2, low: 1, '': 0 };
                  return (priorityOrder[b.priority] || 0) - (priorityOrder[a.priority] || 0);
                })
                .map((question: any, index: number) => (
                  <div key={index} className="border-l-4 border-blue-300 pl-4">
                    <div className="flex items-start justify-between mb-1">
                      <p className="font-medium text-sm leading-relaxed flex-1">{question.question}</p>
                      {question.priority && (
                        <span className={`text-xs ml-2 ${getPriorityColor(question.priority)} capitalize`}>
                          {question.priority}
                        </span>
                      )}
                    </div>
                    {question.category && (
                      <span className="text-xs text-muted-foreground">{question.category}</span>
                    )}
                    {question.notes && (
                      <p className="text-xs text-muted-foreground mt-1 italic">Context: {question.notes}</p>
                    )}
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Empty State */}
      {userData.symptoms.length === 0 && userData.medications.length === 0 && userData.questions.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <FileText className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="mb-2">No information to summarize yet</h3>
            <p className="text-muted-foreground mb-4">
              Start by logging your symptoms, adding medications, or preparing questions to generate a comprehensive summary.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Important Notice */}
      <Card className="border-orange-200 bg-orange-50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5" />
            <div>
              <h4 className="text-sm font-medium text-orange-900">Important Reminder</h4>
              <p className="text-sm text-orange-800 mt-1">
                This summary is for preparation only. Always provide complete and accurate information directly to your doctor during the consultation.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}