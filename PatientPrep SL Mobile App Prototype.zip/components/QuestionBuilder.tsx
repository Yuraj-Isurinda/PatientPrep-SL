import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { MessageCircleQuestion, Plus, Trash2, Lightbulb, HelpCircle } from 'lucide-react';

interface QuestionBuilderProps {
  userData: any;
  setUserData: (data: any) => void;
}

export function QuestionBuilder({ userData, setUserData }: QuestionBuilderProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    question: '',
    category: '',
    priority: '',
    notes: ''
  });
  const [showSuggestions, setShowSuggestions] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleAddQuestion = () => {
    if (formData.question) {
      const newQuestion = {
        ...formData,
        id: Date.now().toString(),
        dateAdded: new Date().toISOString()
      };
      
      setUserData({
        ...userData,
        questions: [...userData.questions, newQuestion]
      });
      
      setFormData({
        question: '',
        category: '',
        priority: '',
        notes: ''
      });
      
      setIsDialogOpen(false);
    }
  };

  const handleDeleteQuestion = (questionId: string) => {
    setUserData({
      ...userData,
      questions: userData.questions.filter((q: any) => q.id !== questionId)
    });
  };

  const handleAddSuggestion = (suggestion: string) => {
    setFormData(prev => ({ ...prev, question: suggestion }));
    setShowSuggestions(false);
  };

  const suggestedQuestions = [
    {
      category: 'General Health',
      questions: [
        'What could be causing my symptoms?',
        'Are there any tests I should take?',
        'When should I come back for a follow-up?',
        'Are there any warning signs I should watch for?'
      ]
    },
    {
      category: 'Lifestyle & Prevention',
      questions: [
        'What lifestyle changes would help my condition?',
        'Are there foods I should avoid?',
        'What type of exercise is safe for me?',
        'How can I prevent this from getting worse?'
      ]
    },
    {
      category: 'Treatment Options',
      questions: [
        'What are my treatment options?',
        'What are the side effects of this medication?',
        'Are there alternative treatments available?',
        'How long will this treatment take to work?'
      ]
    },
    {
      category: 'Daily Life Impact',
      questions: [
        'Can I continue my normal activities?',
        'Is it safe for me to drive?',
        'Will this affect my work?',
        'When can I return to exercise?'
      ]
    }
  ];

  // Get AI suggestions based on logged symptoms
  const getPersonalizedSuggestions = () => {
    const symptoms = userData.symptoms;
    const suggestions: string[] = [];

    symptoms.forEach((symptom: any) => {
      const symptomName = symptom.symptom.toLowerCase();
      
      if (symptomName.includes('pain')) {
        suggestions.push(`What can I do to manage my ${symptom.symptom.toLowerCase()}?`);
        suggestions.push(`Is my ${symptom.symptom.toLowerCase()} a sign of something serious?`);
      }
      
      if (symptomName.includes('headache')) {
        suggestions.push('Could my headaches be related to stress or diet?');
        suggestions.push('What type of headache am I experiencing?');
      }
      
      if (symptomName.includes('fatigue') || symptomName.includes('tired')) {
        suggestions.push('What blood tests should I get for fatigue?');
        suggestions.push('Could my fatigue be related to my sleep or diet?');
      }
    });

    return [...new Set(suggestions)]; // Remove duplicates
  };

  const personalizedSuggestions = getPersonalizedSuggestions();

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2>Questions for Doctor</h2>
          <p className="text-muted-foreground">Prepare questions for your consultation</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Add
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Question</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="question">Question*</Label>
                  <Button 
                    type="button"
                    variant="ghost" 
                    size="sm"
                    onClick={() => setShowSuggestions(!showSuggestions)}
                    className="text-blue-600 hover:text-blue-700"
                  >
                    <Lightbulb className="w-4 h-4 mr-1" />
                    Suggestions
                  </Button>
                </div>
                <Textarea
                  id="question"
                  placeholder="What would you like to ask your doctor?"
                  value={formData.question}
                  onChange={(e) => handleInputChange('question', e.target.value)}
                />
              </div>

              {showSuggestions && (
                <div className="space-y-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  {personalizedSuggestions.length > 0 && (
                    <div>
                      <h4 className="text-sm font-medium text-blue-900 mb-2">
                        Based on your symptoms:
                      </h4>
                      <div className="space-y-1">
                        {personalizedSuggestions.map((suggestion, index) => (
                          <Button
                            key={index}
                            variant="ghost"
                            size="sm"
                            className="w-full justify-start text-left h-auto p-2 text-blue-800 hover:bg-blue-100"
                            onClick={() => handleAddSuggestion(suggestion)}
                          >
                            {suggestion}
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {suggestedQuestions.map((category, categoryIndex) => (
                    <div key={categoryIndex}>
                      <h4 className="text-sm font-medium text-blue-900 mb-2">
                        {category.category}:
                      </h4>
                      <div className="space-y-1">
                        {category.questions.map((question, qIndex) => (
                          <Button
                            key={qIndex}
                            variant="ghost"
                            size="sm"
                            className="w-full justify-start text-left h-auto p-2 text-blue-800 hover:bg-blue-100"
                            onClick={() => handleAddSuggestion(question)}
                          >
                            {question}
                          </Button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Input
                    id="category"
                    placeholder="e.g., Treatment"
                    value={formData.category}
                    onChange={(e) => handleInputChange('category', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="priority">Priority</Label>
                  <select 
                    id="priority"
                    className="w-full p-2 border border-border rounded-md bg-input-background"
                    value={formData.priority}
                    onChange={(e) => handleInputChange('priority', e.target.value)}
                  >
                    <option value="">Select</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Context/Notes</Label>
                <Textarea
                  id="notes"
                  placeholder="Any additional context for this question..."
                  value={formData.notes}
                  onChange={(e) => handleInputChange('notes', e.target.value)}
                />
              </div>

              <Button onClick={handleAddQuestion} className="w-full">
                Add Question
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Questions List */}
      {userData.questions.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <HelpCircle className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="mb-2">No questions prepared</h3>
            <p className="text-muted-foreground mb-4">Prepare questions to make the most of your consultation time.</p>
            <Button onClick={() => setIsDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add First Question
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {userData.questions
            .sort((a: any, b: any) => {
              const priorityOrder = { high: 3, medium: 2, low: 1, '': 0 };
              return (priorityOrder[b.priority] || 0) - (priorityOrder[a.priority] || 0);
            })
            .map((question: any, index: number) => (
              <Card key={question.id}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-sm text-muted-foreground">#{index + 1}</span>
                        {question.priority && (
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            question.priority === 'high' 
                              ? 'bg-red-100 text-red-800' 
                              : question.priority === 'medium'
                              ? 'bg-yellow-100 text-yellow-800'
                              : 'bg-green-100 text-green-800'
                          }`}>
                            {question.priority} priority
                          </span>
                        )}
                        {question.category && (
                          <span className="px-2 py-1 bg-muted rounded-full text-xs">
                            {question.category}
                          </span>
                        )}
                      </div>
                      <CardTitle className="text-base leading-relaxed">
                        {question.question}
                      </CardTitle>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteQuestion(question.id)}
                      className="text-destructive hover:text-destructive ml-2"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardHeader>
                {question.notes && (
                  <CardContent className="pt-0">
                    <p className="text-sm bg-muted/50 p-3 rounded-lg">
                      <strong>Context:</strong> {question.notes}
                    </p>
                  </CardContent>
                )}
              </Card>
            ))}
        </div>
      )}

      {/* AI Tips */}
      <Card className="border-green-200 bg-green-50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Lightbulb className="w-5 h-5 text-green-600 mt-0.5" />
            <div>
              <h4 className="text-sm font-medium text-green-900">Smart Questions</h4>
              <p className="text-sm text-green-800 mt-1">
                Good questions help you understand your condition better. Ask about causes, treatment options, and what to expect.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}