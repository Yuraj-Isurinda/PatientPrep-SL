import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Settings as SettingsIcon, Cloud, Shield, User, LogOut, Upload, Download, AlertCircle, CheckCircle } from 'lucide-react';
import { authService } from '../utils/auth';
import { cloudSyncService } from '../utils/cloudSync';

interface SettingsProps {
  user: any;
  session: any;
  userData: any;
  setUserData: (data: any) => void;
  onSignOut: () => void;
}

export function Settings({ user, session, userData, setUserData, onSignOut }: SettingsProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [cloudSyncEnabled, setCloudSyncEnabled] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });

  const handleSignOut = async () => {
    setIsLoading(true);
    const { error } = await authService.signOut();
    if (error) {
      setMessage({ type: 'error', text: error });
    } else {
      onSignOut();
      setIsDialogOpen(false);
    }
    setIsLoading(false);
  };

  const handleEnableCloudSync = async () => {
    if (!cloudSyncEnabled) {
      setIsLoading(true);
      const result = await cloudSyncService.syncData(userData, session.access_token, true);
      
      if (result.success) {
        setCloudSyncEnabled(true);
        setMessage({ type: 'success', text: 'Cloud sync enabled! Your data has been backed up securely.' });
      } else {
        setMessage({ type: 'error', text: result.error });
      }
      setIsLoading(false);
    } else {
      setCloudSyncEnabled(false);
      setMessage({ type: 'success', text: 'Cloud sync disabled. Your data will remain local only.' });
    }
  };

  const handleSyncNow = async () => {
    if (!cloudSyncEnabled) return;
    
    setIsLoading(true);
    const result = await cloudSyncService.syncData(userData, session.access_token, false);
    
    if (result.success) {
      setMessage({ type: 'success', text: 'Data synced successfully!' });
    } else {
      setMessage({ type: 'error', text: result.error });
    }
    setIsLoading(false);
  };

  const handleRestoreFromCloud = async () => {
    setIsLoading(true);
    const result = await cloudSyncService.retrieveData(session.access_token);
    
    if (result.success && result.hasCloudData) {
      setUserData(result.data);
      setMessage({ type: 'success', text: 'Data restored from cloud backup!' });
    } else if (result.success && !result.hasCloudData) {
      setMessage({ type: 'error', text: 'No cloud backup found.' });
    } else {
      setMessage({ type: 'error', text: result.error });
    }
    setIsLoading(false);
  };

  return (
    <div className="p-4">
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogTrigger asChild>
          <Button variant="ghost" size="sm" className="w-full justify-start">
            <SettingsIcon className="w-4 h-4 mr-2" />
            Settings
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <SettingsIcon className="w-5 h-5" />
              Settings
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <User className="w-4 h-4" />
                  Account
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <Label className="text-sm text-muted-foreground">Name</Label>
                  <p className="font-medium">{user?.name || 'Not provided'}</p>
                </div>
                <div>
                  <Label className="text-sm text-muted-foreground">Email</Label>
                  <p className="font-medium">{user?.email}</p>
                </div>
                <Button 
                  variant="destructive" 
                  size="sm" 
                  onClick={handleSignOut}
                  disabled={isLoading}
                  className="w-full"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sign Out
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Cloud className="w-4 h-4" />
                  Cloud Sync
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <Label>Enable Cloud Backup</Label>
                    <p className="text-xs text-muted-foreground">
                      Securely backup your health data to the cloud
                    </p>
                  </div>
                  <Switch 
                    checked={cloudSyncEnabled} 
                    onCheckedChange={handleEnableCloudSync}
                    disabled={isLoading}
                  />
                </div>
                
                {cloudSyncEnabled && (
                  <div className="space-y-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={handleSyncNow}
                      disabled={isLoading}
                      className="w-full"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Sync Now
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={handleRestoreFromCloud}
                      disabled={isLoading}
                      className="w-full"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Restore from Cloud
                    </Button>
                  </div>
                )}

                <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="flex items-start gap-2">
                    <Shield className="w-4 h-4 text-blue-600 mt-0.5" />
                    <div>
                      <p className="text-xs text-blue-800">
                        <strong>Privacy Notice:</strong> Your health data is encrypted and stored securely. 
                        You can disable cloud sync at any time, and your local data will remain unaffected.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Your Data</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <p className="text-xl font-medium text-primary">{userData.symptoms?.length || 0}</p>
                    <p className="text-xs text-muted-foreground">Symptoms</p>
                  </div>
                  <div>
                    <p className="text-xl font-medium text-primary">{userData.medications?.length || 0}</p>
                    <p className="text-xs text-muted-foreground">Medications</p>
                  </div>
                  <div>
                    <p className="text-xl font-medium text-primary">{userData.questions?.length || 0}</p>
                    <p className="text-xs text-muted-foreground">Questions</p>
                  </div>
                  <div>
                    <p className="text-xl font-medium text-primary">{userData.appointments?.length || 0}</p>
                    <p className="text-xs text-muted-foreground">Appointments</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {message.text && (
              <div className={`p-3 rounded-lg border flex items-center gap-2 ${
                message.type === 'success' 
                  ? 'bg-green-50 border-green-200 text-green-800' 
                  : 'bg-red-50 border-red-200 text-red-800'
              }`}>
                {message.type === 'success' ? 
                  <CheckCircle className="w-4 h-4" /> : 
                  <AlertCircle className="w-4 h-4" />
                }
                <p className="text-sm">{message.text}</p>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}