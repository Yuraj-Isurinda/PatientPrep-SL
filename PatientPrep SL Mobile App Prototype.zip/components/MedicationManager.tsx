import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Pill, Plus, Trash2, AlertCircle } from 'lucide-react';

interface MedicationManagerProps {
  userData: any;
  setUserData: (data: any) => void;
}

export function MedicationManager({ userData, setUserData }: MedicationManagerProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    dosage: '',
    frequency: '',
    purpose: '',
    prescribedBy: '',
    startDate: '',
    notes: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleAddMedication = () => {
    if (formData.name) {
      const newMedication = {
        ...formData,
        id: Date.now().toString(),
        dateAdded: new Date().toISOString()
      };
      
      setUserData({
        ...userData,
        medications: [...userData.medications, newMedication]
      });
      
      setFormData({
        name: '',
        dosage: '',
        frequency: '',
        purpose: '',
        prescribedBy: '',
        startDate: '',
        notes: ''
      });
      
      setIsDialogOpen(false);
    }
  };

  const handleDeleteMedication = (medicationId: string) => {
    setUserData({
      ...userData,
      medications: userData.medications.filter((med: any) => med.id !== medicationId)
    });
  };

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2>Medications</h2>
          <p className="text-muted-foreground">Keep track of all your medications</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Add
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Medication</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Medication Name*</Label>
                <Input
                  id="name"
                  placeholder="e.g., Paracetamol, Vitamin D"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="dosage">Dosage</Label>
                  <Input
                    id="dosage"
                    placeholder="e.g., 500mg"
                    value={formData.dosage}
                    onChange={(e) => handleInputChange('dosage', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="frequency">Frequency</Label>
                  <Select value={formData.frequency} onValueChange={(value) => handleInputChange('frequency', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="once-daily">Once daily</SelectItem>
                      <SelectItem value="twice-daily">Twice daily</SelectItem>
                      <SelectItem value="three-times-daily">Three times daily</SelectItem>
                      <SelectItem value="four-times-daily">Four times daily</SelectItem>
                      <SelectItem value="as-needed">As needed</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="purpose">Purpose/Condition</Label>
                <Input
                  id="purpose"
                  placeholder="e.g., Blood pressure, Pain relief"
                  value={formData.purpose}
                  onChange={(e) => handleInputChange('purpose', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="prescribedBy">Prescribed By</Label>
                <Input
                  id="prescribedBy"
                  placeholder="e.g., Dr. Smith, Over-the-counter"
                  value={formData.prescribedBy}
                  onChange={(e) => handleInputChange('prescribedBy', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="startDate">Start Date</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={formData.startDate}
                  onChange={(e) => handleInputChange('startDate', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  placeholder="Any special instructions, side effects, etc."
                  value={formData.notes}
                  onChange={(e) => handleInputChange('notes', e.target.value)}
                />
              </div>

              <Button onClick={handleAddMedication} className="w-full">
                Add Medication
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Medications List */}
      {userData.medications.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <Pill className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="mb-2">No medications listed</h3>
            <p className="text-muted-foreground mb-4">Add all your medications, including over-the-counter drugs and supplements.</p>
            <Button onClick={() => setIsDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add First Medication
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {userData.medications.map((medication: any) => (
            <Card key={medication.id}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Pill className="w-4 h-4" />
                      {medication.name}
                    </CardTitle>
                    <div className="flex items-center gap-4 mt-1">
                      {medication.dosage && (
                        <span className="text-sm text-muted-foreground">{medication.dosage}</span>
                      )}
                      {medication.frequency && (
                        <span className="px-2 py-1 bg-muted rounded-full text-xs">
                          {medication.frequency.replace('-', ' ')}
                        </span>
                      )}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDeleteMedication(medication.id)}
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="pt-0 space-y-3">
                <div className="grid grid-cols-1 gap-2 text-sm">
                  {medication.purpose && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Purpose:</span>
                      <span>{medication.purpose}</span>
                    </div>
                  )}
                  {medication.prescribedBy && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Prescribed by:</span>
                      <span>{medication.prescribedBy}</span>
                    </div>
                  )}
                  {medication.startDate && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Started:</span>
                      <span>{new Date(medication.startDate).toLocaleDateString()}</span>
                    </div>
                  )}
                </div>
                {medication.notes && (
                  <p className="text-sm bg-muted/50 p-2 rounded">{medication.notes}</p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* AI Tips */}
      <div className="space-y-3">
        <Card className="border-green-200 bg-green-50">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-green-600 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium text-green-900">Don't Forget!</h4>
                <p className="text-sm text-green-800 mt-1">
                  Include vitamins, herbal supplements, and over-the-counter medications. These can interact with prescribed drugs.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium text-blue-900">Pro Tip</h4>
                <p className="text-sm text-blue-800 mt-1">
                  Bring the actual medication bottles or packaging to your appointment when possible. This helps your doctor verify exact formulations.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}