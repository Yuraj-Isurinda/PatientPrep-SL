import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { Settings as SettingsIcon, Shield, Download, Upload, AlertCircle, Trash2 } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface SimpleSettingsProps {
  userData: any;
  setUserData: (data: any) => void;
  setCurrentView: (view: string) => void;
}

export function SimpleSettings({ userData, setUserData, setCurrentView }: SimpleSettingsProps) {
  const [preferences, setPreferences] = useState({
    reminder_notifications: true,
    data_export_enabled: true
  });

  const handleExportData = () => {
    try {
      const dataToExport = {
        ...userData,
        exportDate: new Date().toISOString(),
        appVersion: 'PatientPrep SL v1.0'
      };
      
      const dataStr = JSON.stringify(dataToExport, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `patientprep-backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      toast.success('Data exported successfully!');
    } catch (error) {
      toast.error('Failed to export data');
    }
  };

  const handleImportData = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;
      
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const importedData = JSON.parse(e.target?.result as string);
          
          // Validate the data structure
          if (importedData.appointments && importedData.symptoms && importedData.medications) {
            setUserData({
              appointments: importedData.appointments || [],
              symptoms: importedData.symptoms || [],
              medications: importedData.medications || [],
              questions: importedData.questions || [],
              consultationNotes: importedData.consultationNotes || []
            });
            toast.success('Data imported successfully!');
          } else {
            toast.error('Invalid backup file format');
          }
        } catch (error) {
          toast.error('Failed to import data - invalid file');
        }
      };
      reader.readAsText(file);
    };
    
    input.click();
  };

  const handleClearAllData = () => {
    if (window.confirm('Are you sure you want to clear all your data? This action cannot be undone.')) {
      setUserData({
        appointments: [],
        symptoms: [],
        medications: [],
        questions: [],
        consultationNotes: []
      });
      toast.success('All data cleared');
    }
  };

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2>Settings</h2>
          <p className="text-muted-foreground">Manage your app preferences</p>
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={() => setCurrentView('home')}
        >
          Back
        </Button>
      </div>

      {/* App Preferences */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <SettingsIcon className="w-5 h-5" />
            Preferences
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label>Reminder Notifications</Label>
              <p className="text-sm text-muted-foreground">
                Get browser notifications for upcoming appointments
              </p>
            </div>
            <Switch
              checked={preferences.reminder_notifications}
              onCheckedChange={(checked) => 
                setPreferences({ ...preferences, reminder_notifications: checked })
              }
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label>Data Export</Label>
              <p className="text-sm text-muted-foreground">
                Allow exporting your data as backup files
              </p>
            </div>
            <Switch
              checked={preferences.data_export_enabled}
              onCheckedChange={(checked) => 
                setPreferences({ ...preferences, data_export_enabled: checked })
              }
            />
          </div>
        </CardContent>
      </Card>

      {/* Data Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            Data Management
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleExportData}
              disabled={!preferences.data_export_enabled}
              className="flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              Export Data
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleImportData}
              className="flex items-center gap-2"
            >
              <Upload className="w-4 h-4" />
              Import Data
            </Button>
          </div>
          
          <div className="pt-4 border-t">
            <Button
              variant="destructive"
              size="sm"
              onClick={handleClearAllData}
              className="w-full flex items-center gap-2"
            >
              <Trash2 className="w-4 h-4" />
              Clear All Data
            </Button>
            <p className="text-xs text-muted-foreground text-center mt-2">
              This will permanently delete all your consultation data
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Your Data Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Your Data</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-3 bg-muted/50 rounded-lg">
              <p className="text-lg font-medium">{userData.symptoms?.length || 0}</p>
              <p className="text-sm text-muted-foreground">Symptoms</p>
            </div>
            <div className="text-center p-3 bg-muted/50 rounded-lg">
              <p className="text-lg font-medium">{userData.medications?.length || 0}</p>
              <p className="text-sm text-muted-foreground">Medications</p>
            </div>
            <div className="text-center p-3 bg-muted/50 rounded-lg">
              <p className="text-lg font-medium">{userData.questions?.length || 0}</p>
              <p className="text-sm text-muted-foreground">Questions</p>
            </div>
            <div className="text-center p-3 bg-muted/50 rounded-lg">
              <p className="text-lg font-medium">{userData.appointments?.length || 0}</p>
              <p className="text-sm text-muted-foreground">Appointments</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Privacy Notice */}
      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Shield className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <h4 className="text-sm font-medium text-blue-900">Privacy First</h4>
              <p className="text-sm text-blue-800 mt-1">
                All your health data is stored locally on your device. No information is sent to external servers unless you explicitly export it.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* PDPA Compliance */}
      <Card className="border-orange-200 bg-orange-50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5" />
            <div>
              <h4 className="text-sm font-medium text-orange-900">Data Protection</h4>
              <p className="text-sm text-orange-800 mt-1">
                This app complies with Sri Lanka's PDPA. Your data remains under your control and can be exported or deleted at any time.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}