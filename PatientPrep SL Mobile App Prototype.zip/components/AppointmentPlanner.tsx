import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Calendar, Clock, User, Stethoscope, Plus, Trash2 } from 'lucide-react';

interface AppointmentPlannerProps {
  userData: any;
  setUserData: (data: any) => void;
}

export function AppointmentPlanner({ userData, setUserData }: AppointmentPlannerProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    doctorName: '',
    specialty: '',
    date: '',
    time: '',
    location: '',
    notes: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleAddAppointment = () => {
    if (formData.doctorName && formData.date && formData.time) {
      const newAppointment = {
        ...formData,
        id: Date.now().toString()
      };
      
      setUserData({
        ...userData,
        appointments: [...userData.appointments, newAppointment]
      });
      
      setFormData({
        doctorName: '',
        specialty: '',
        date: '',
        time: '',
        location: '',
        notes: ''
      });
      
      setIsDialogOpen(false);
    }
  };

  const handleDeleteAppointment = (appointmentId: string) => {
    setUserData({
      ...userData,
      appointments: userData.appointments.filter((apt: any) => apt.id !== appointmentId)
    });
  };

  const sortedAppointments = [...userData.appointments].sort((a, b) => 
    new Date(a.date).getTime() - new Date(b.date).getTime()
  );

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2>Appointments</h2>
          <p className="text-muted-foreground">Manage your medical appointments</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Add
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>New Appointment</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="doctorName">Doctor's Name*</Label>
                <Input
                  id="doctorName"
                  placeholder="Dr. Smith"
                  value={formData.doctorName}
                  onChange={(e) => handleInputChange('doctorName', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="specialty">Specialty</Label>
                <Input
                  id="specialty"
                  placeholder="Cardiologist"
                  value={formData.specialty}
                  onChange={(e) => handleInputChange('specialty', e.target.value)}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="date">Date*</Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.date}
                    onChange={(e) => handleInputChange('date', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="time">Time*</Label>
                  <Input
                    id="time"
                    type="time"
                    value={formData.time}
                    onChange={(e) => handleInputChange('time', e.target.value)}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  placeholder="Hospital/Clinic address"
                  value={formData.location}
                  onChange={(e) => handleInputChange('location', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  placeholder="Any additional notes..."
                  value={formData.notes}
                  onChange={(e) => handleInputChange('notes', e.target.value)}
                />
              </div>
              <Button onClick={handleAddAppointment} className="w-full">
                Add Appointment
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Appointments List */}
      {sortedAppointments.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <Calendar className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="mb-2">No appointments scheduled</h3>
            <p className="text-muted-foreground mb-4">Add your first appointment to get started with consultation preparation.</p>
            <Button onClick={() => setIsDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Appointment
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {sortedAppointments.map((appointment: any, index: number) => {
            const appointmentDate = new Date(appointment.date);
            const isUpcoming = appointmentDate >= new Date();
            
            return (
              <Card key={appointment.id} className={isUpcoming ? 'border-primary/20 bg-primary/5' : ''}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-base flex items-center gap-2">
                        <User className="w-4 h-4" />
                        {appointment.doctorName}
                      </CardTitle>
                      {appointment.specialty && (
                        <p className="text-sm text-muted-foreground flex items-center gap-2 mt-1">
                          <Stethoscope className="w-4 h-4" />
                          {appointment.specialty}
                        </p>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteAppointment(appointment.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <span>{appointmentDate.toLocaleDateString('en-GB', {
                        weekday: 'short',
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric'
                      })}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <span>{appointment.time}</span>
                    </div>
                    {appointment.location && (
                      <p className="text-sm text-muted-foreground">{appointment.location}</p>
                    )}
                    {appointment.notes && (
                      <p className="text-sm bg-muted/50 p-2 rounded">{appointment.notes}</p>
                    )}
                  </div>
                  {isUpcoming && (
                    <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                      <p className="text-sm text-blue-800">
                        📋 <strong>Ready to prepare?</strong> Start logging your symptoms and preparing questions for this appointment.
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}