import React from 'react';
import { LucideIcon } from 'lucide-react';

interface NavigationItem {
  id: string;
  label: string;
  icon: LucideIcon;
}

interface NavigationBarProps {
  items: NavigationItem[];
  currentView: string;
  setCurrentView: (view: string) => void;
}

export function NavigationBar({ items, currentView, setCurrentView }: NavigationBarProps) {
  // Show key navigation items in bottom bar
  const primaryItems = items.filter(item => 
    ['home', 'symptoms', 'medications', 'questions', 'settings'].includes(item.id)
  );

  return (
    <nav className="bg-card border-t border-border">
      <div className="flex">
        {primaryItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => setCurrentView(item.id)}
              className={`flex-1 flex flex-col items-center py-2 px-1 text-xs transition-colors ${
                isActive
                  ? 'text-primary bg-primary/5'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Icon className={`w-5 h-5 mb-1 ${isActive ? 'text-primary' : ''}`} />
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}