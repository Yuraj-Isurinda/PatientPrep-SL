import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors({
  origin: '*',
  allowHeaders: ['*'],
  allowMethods: ['*'],
}));

app.use('*', logger(console.log));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Health check
app.get('/make-server-26c2a481/health', (c) => {
  return c.json({ status: 'PatientPrep SL server is running', timestamp: new Date().toISOString() });
});

// Authentication routes
app.post('/make-server-26c2a481/auth/signup', async (c) => {
  try {
    const { email, password, fullName } = await c.req.json();
    
    if (!email || !password) {
      return c.json({ error: 'Email and password are required' }, 400);
    }

    console.log(`Creating new user account for email: ${email}`);
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { 
        full_name: fullName,
        privacy_consent: true,
        backup_enabled: false 
      },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      console.log(`User creation error: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }

    console.log(`Successfully created user: ${data.user.id}`);
    return c.json({ 
      user: data.user,
      message: 'Account created successfully. You can now sign in.' 
    });
    
  } catch (error) {
    console.log(`Signup error: ${error.message}`);
    return c.json({ error: 'Failed to create account' }, 500);
  }
});

// Encrypted data backup routes (with explicit user consent)
app.post('/make-server-26c2a481/backup/save', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (authError || !user) {
      console.log(`Backup save authorization error: ${authError?.message}`);
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { dataType, data } = await c.req.json();
    
    if (!dataType || !data) {
      return c.json({ error: 'Data type and data are required' }, 400);
    }

    // Simple encryption using base64 (in production, use proper encryption)
    const encryptedData = btoa(JSON.stringify(data));
    
    // Store in key-value store with user-specific key
    const backupKey = `backup:${user.id}:${dataType}`;
    const backupRecord = {
      user_id: user.id,
      data_type: dataType,
      encrypted_data: encryptedData,
      last_updated: new Date().toISOString()
    };
    
    await kv.set(backupKey, backupRecord);
    
    console.log(`Successfully backed up ${dataType} for user ${user.id}`);
    return c.json({ success: true, message: 'Data backed up successfully' });
    
  } catch (error) {
    console.log(`Backup save error: ${error.message}`);
    return c.json({ error: 'Failed to backup data' }, 500);
  }
});

app.get('/make-server-26c2a481/backup/restore', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (authError || !user) {
      console.log(`Backup restore authorization error: ${authError?.message}`);
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const dataType = c.req.query('dataType');
    
    if (!dataType) {
      return c.json({ error: 'Data type is required' }, 400);
    }

    // Retrieve from key-value store
    const backupKey = `backup:${user.id}:${dataType}`;
    const backupRecord = await kv.get(backupKey);
    
    if (!backupRecord) {
      return c.json({ data: null, message: 'No backup found for this data type' });
    }

    // Decrypt data
    const decryptedData = JSON.parse(atob(backupRecord.encrypted_data));
    
    console.log(`Successfully restored ${dataType} for user ${user.id}`);
    return c.json({ 
      data: decryptedData, 
      lastUpdated: backupRecord.last_updated 
    });
    
  } catch (error) {
    console.log(`Backup restore error: ${error.message}`);
    return c.json({ error: 'Failed to restore data' }, 500);
  }
});

// User preferences routes
app.get('/make-server-26c2a481/user/preferences', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const prefsKey = `preferences:${user.id}`;
    const preferences = await kv.get(prefsKey) || {
      backup_enabled: false,
      reminder_notifications: true,
      data_retention_days: 365
    };
    
    return c.json({ preferences });
    
  } catch (error) {
    console.log(`Get preferences error: ${error.message}`);
    return c.json({ error: 'Failed to get preferences' }, 500);
  }
});

app.post('/make-server-26c2a481/user/preferences', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const preferences = await c.req.json();
    const prefsKey = `preferences:${user.id}`;
    
    await kv.set(prefsKey, {
      ...preferences,
      updated_at: new Date().toISOString()
    });
    
    console.log(`Updated preferences for user ${user.id}`);
    return c.json({ success: true, message: 'Preferences updated successfully' });
    
  } catch (error) {
    console.log(`Update preferences error: ${error.message}`);
    return c.json({ error: 'Failed to update preferences' }, 500);
  }
});

Deno.serve(app.fetch);